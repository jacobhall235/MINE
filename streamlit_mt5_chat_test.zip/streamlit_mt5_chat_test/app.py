import streamlit as st
from datetime import datetime
import json
from modules import chat_logic
from modules.logger import log

# ✅ Load extra UI modules automatically
from modules.load_modules import render_all  # 👈 SINGLE addition
render_all()  # 👈 Mounts all additional UI like MT5 sidebar

# 🔁 DEBUG — Show every rerun
log(f"🔁 Streamlit rerun @ {datetime.now()}", actor="SYSTEM")
log(f"🔍 session_state keys: {list(st.session_state.keys())}", actor="SYSTEM")
log("📲 App launched", actor="SYSTEM")

# 🔧 UI Setup
st.set_page_config(page_title="Streamlit ChatBot", layout="wide")
st.title("🧠 Streamlit ChatBot (Minimal Debug Mode)")
log("🖼️ UI layout and title set", actor="SYSTEM")

# ✅ Use dynamic session selection from sidebar
selected_session = st.session_state.get("session_select", "Chat 1")
st.session_state.current_session = selected_session
log(f"👤 Using selected session: {selected_session}", actor="SYSTEM")

# 🔄 Track messages
messages_exist = "messages" in st.session_state and st.session_state.messages
log(f"🔍 Messages already in session before load? {messages_exist}", actor="SYSTEM")

# 🧪 DEBUG ALL MESSAGES STRUCTURE
if "messages" in st.session_state:
    for i, msg in enumerate(st.session_state.messages):
        if isinstance(msg, dict):
            role = msg.get("role", "?")
            content_preview = msg.get("content", "")[:60].replace("\n", " ")
            log(f"   🗒️ Message[{i}] {role}: {content_preview}", actor="SYSTEM")
        else:
            log(f"   ⚠️ Message[{i}] is not a dict: {repr(msg)}", actor="SYSTEM")

# 🧾 Write snapshot to debug file
try:
    with open("debug_app_snapshot.json", "w", encoding="utf-8") as f:
        snapshot = {
            "current_session": selected_session,
            "messages": st.session_state.get("messages", []),
            "all_keys": list(st.session_state.keys())
        }
        json.dump(snapshot, f, indent=2, ensure_ascii=False)
    log("📦 Wrote debug snapshot to debug_app_snapshot.json", actor="SYSTEM")
except Exception as e:
    log(f"⚠️ Failed to save app snapshot: {e}", actor="SYSTEM")

# 💬 Render the chat interface
log("💬 Rendering chat interface", actor="SYSTEM")
chat_logic.render(selected_session)
