import os
from datetime import datetime
from collections import deque

# ✅ Ensure logs directory exists
LOG_FILE = "logs/system_log.txt"
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)

# ✅ Settings
VERBOSE_UI = False              # Set to True to allow all logs
MAX_LOG_HISTORY = 100           # How many past logs to remember for filtering
LOG_SPAM_PATTERNS = [
    "Rendering", "Retrieved sessions", "Sidebar loaded", "App launched",
    "Rendering chat interface", "Rendering delete UI", "Floating PnL"
]

# Internal memory for deduplication
_logged_messages = deque(maxlen=MAX_LOG_HISTORY)

def _is_spam(message):
    return any(pat in message for pat in LOG_SPAM_PATTERNS)

def _already_logged(key):
    return key in _logged_messages

def log(message, actor="SYSTEM", context="General", force=False):
    """
    Logs an event with timestamp, actor (USER/SYSTEM), and optional context.
    Filters duplicate or spammy logs unless force=True.
    """
    key = f"{actor}|{context}|{message}"

    if not force and not VERBOSE_UI:
        if _is_spam(message) and _already_logged(key):
            return
        _logged_messages.append(key)

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    actor_tag = "👤 USER" if actor.upper() == "USER" else "⚙️ SYSTEM"
    entry = f"[{timestamp}] [{actor_tag}] [{context}] {message}\n"

    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(entry)
    except Exception as e:
        print(f"[❌ Logger Error] {e}")

def log_event(event_type, message):
    """
    Structured logger for categorized events like 'error', 'trade', etc.
    Always logs regardless of VERBOSE_UI setting.
    """
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    icons = {
        "error": "❌",
        "warn": "⚠️",
        "info": "ℹ️",
        "trade": "📈",
        "system": "🖥️",
    }
    icon = icons.get(event_type.lower(), "📌")
    entry = f"[{timestamp}] {icon} [{event_type.upper()}] {message}\n"

    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(entry)
    except Exception as e:
        print(f"[❌ Logger Error] {e}")
