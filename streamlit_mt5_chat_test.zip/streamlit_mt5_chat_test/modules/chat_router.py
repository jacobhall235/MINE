import streamlit as st
from modules import chat_logic
from modules.error_handler import handle
from modules.logger import log  # ✅ Add logger

def render(session_name):
    try:
        log(f"🧾 Rendering chat for session: {session_name}", actor="SYSTEM")
        chat_logic.render(session_name)
    except Exception as e:
        handle(e, context="chat_router")
        log(f"❌ Error rendering chat for session '{session_name}': {e}", actor="SYSTEM")
