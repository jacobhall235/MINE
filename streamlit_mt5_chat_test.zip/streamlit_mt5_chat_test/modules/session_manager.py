import json
import os
import copy
import streamlit as st
from modules.error_handler import handle
from modules.logger import log

MEMORY_FILE = "memory.json"
DEBUG_DUMP_FILE = "debug_memory_snapshot.json"

def get_sessions():
    try:
        if not os.path.exists(MEMORY_FILE):
            log("📁 No memory file found. Returning empty session list.", actor="SYSTEM")
            return []
        with open(MEMORY_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        log(f"📄 Retrieved sessions: {list(data.keys())}", actor="SYSTEM")
        return list(data.keys())
    except Exception as e:
        handle(e, context="session_manager → get_sessions")
        return []

@st.cache_data(show_spinner=False)
def load_memory(session_name):
    try:
        if not os.path.exists(MEMORY_FILE):
            log(f"📁 No memory file. Cannot load session: {session_name}", actor="SYSTEM")
            return []
        with open(MEMORY_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)

        session_messages = data.get(session_name, [])
        log(f"📂 Loaded session '{session_name}' → {len(session_messages)} messages", actor="SYSTEM")
        for i, msg in enumerate(session_messages[-3:]):
            log(f"   📥 [{i}] {msg.get('role', '?')}: {msg.get('content', '')[:60]}", actor="DEBUG")
        return session_messages
    except Exception as e:
        handle(e, context="session_manager → load_memory")
        return []

def invalidate_session_cache(session_name):
    try:
        load_memory.clear()  # 🔄 Clear all cached sessions
        log(f"🧹 Cache invalidated for session '{session_name}'", actor="SYSTEM")
    except Exception as e:
        handle(e, context="session_manager → invalidate_session_cache")

def save_memory(session_name, messages):
    try:
        messages_copy = copy.deepcopy(messages)
        log(f"💾 Preparing to save session '{session_name}' with {len(messages_copy)} messages", actor="SYSTEM")

        for i, msg in enumerate(messages_copy[-3:]):
            log(f"   🧾 [{i}] {msg.get('role', '?')}: {msg.get('content', '')[:60]}", actor="DEBUG")

        if os.path.exists(MEMORY_FILE):
            with open(MEMORY_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            log(f"🧠 Existing memory.json contains sessions: {list(data.keys())}", actor="DEBUG")
        else:
            data = {}

        data[session_name] = messages_copy

        with open(MEMORY_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        log(f"✅ [CONFIRMED WRITE] Session '{session_name}' saved with {len(messages_copy)} messages", actor="SYSTEM")

        with open(DEBUG_DUMP_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        log("🧾 Debug dump of memory.json saved to debug_memory_snapshot.json", actor="SYSTEM")

        invalidate_session_cache(session_name)

    except Exception as e:
        import traceback
        log(f"❌ Exception during save_memory:\n{traceback.format_exc()}", actor="SYSTEM")
        handle(e, context="session_manager → save_memory")

def load_session(session_name):
    return load_memory(session_name)

def save_session(session_name, messages):
    save_memory(session_name, messages)

def add_session():
    try:
        sessions = get_sessions()
        next_id = 1
        while f"Chat {next_id}" in sessions:
            next_id += 1
        new_session = f"Chat {next_id}"
        save_memory(new_session, [])
        log(f"➕ New session created: {new_session}", actor="USER")
        return new_session
    except Exception as e:
        handle(e, context="session_manager → add_session")
        return "Chat_Error"

def delete_session(session_name):
    try:
        if not os.path.exists(MEMORY_FILE):
            log(f"⚠️ Tried to delete session '{session_name}' but memory file does not exist.", actor="SYSTEM")
            return

        with open(MEMORY_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)

        if session_name in data:
            del data[session_name]
            with open(MEMORY_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            log(f"🗑️ Deleted session: {session_name}", actor="USER")
            invalidate_session_cache(session_name)
        else:
            log(f"⚠️ Session '{session_name}' not found for deletion.", actor="SYSTEM")
    except Exception as e:
        handle(e, context="session_manager → delete_session")
