import traceback
import datetime
import streamlit as st
from modules.logger import log  # ✅ New super logger

LOG_FILE = "error_log.txt"

def log_error(error: Exception, context: str = "General"):
    error_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    tb = traceback.format_exc()

    log_entry = (
        f"[{error_time}] [Context: {context}]\n"
        f"Error: {str(error)}\n"
        f"Traceback:\n{tb}\n"
        f"{'-'*60}\n"
    )

    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(log_entry)

    # ✅ Also log to app_log.txt via super logger
    log(f"❌ Error in '{context}': {str(error)}", actor="SYSTEM")
    log(f"🪵 Traceback: {tb.strip()}", actor="SYSTEM")

def display_error_ui(error: Exception, context: str = "General"):
    st.error(f"⚠️ An error occurred in: `{context}`")
    with st.expander("See full details"):
        st.code(traceback.format_exc())

def handle(error: Exception, context: str = "General", show_ui: bool = True):
    log_error(error, context)
    if show_ui:
        display_error_ui(error, context)
