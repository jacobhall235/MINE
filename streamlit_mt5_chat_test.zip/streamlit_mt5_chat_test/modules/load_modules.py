# modules/load_modules.py

import streamlit as st  # ✅ Required to access session_state
from modules.mt5_ui import render as render_mt5_ui
from modules.session_ui import render as render_session_ui
from modules.delete_ui import render as render_delete_ui  # ✅ Added delete_ui render
from modules.live_runner_ui import render_live_sidebar  # ✅ Added live runner UI

def render_all():
    render_session_ui()   # ✅ Sessions first — UI logic order matters
    render_mt5_ui()
    render_delete_ui()  # 🛠️ FIXED: Removed argument — function takes none
    render_live_sidebar()  # ✅ Show floating PnL + symbol in sidebar
