# modules/live_runner_ui.py

import streamlit as st
from modules.live_runner import get_latest_cached_pnl, get_current_symbol
from modules.logger import log

def render_live_sidebar():
    st.sidebar.markdown("### 📡 Live Trading Status")

    # 🛠️ ONLY autorefresh AFTER messages are loaded to avoid interrupting assistant reply
    if "messages" in st.session_state and st.session_state.messages:
        from streamlit_autorefresh import st_autorefresh
        st_autorefresh(interval=3000, key="live_sidebar_refresh")

    # 📊 Symbol
    symbol = get_current_symbol()
    st.sidebar.markdown(f"**📊 Symbol:** `{symbol}`")

    # 💹 Floating PnL
    try:
        pnl = get_latest_cached_pnl()
        if pnl is None:
            raise ValueError
        pnl_display = f"{pnl:+.2f}"
        pnl_color = "green" if pnl >= 0 else "red"
        st.sidebar.markdown(
            f"<span style='color:{pnl_color}; font-weight:bold;'>💹 Floating PnL: {pnl_display}</span>",
            unsafe_allow_html=True
        )
        log(f"📈 Live Sidebar → Floating PnL: {pnl_display}", actor="SYSTEM")
    except:
        st.sidebar.markdown("**💹 Floating PnL:** `--` *(not available)*")
