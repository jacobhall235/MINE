import streamlit as st
import openai
import json
import copy
from datetime import datetime

from modules.logger import log
from modules.session_manager import save_session, load_session  # ✅ Added load_session
from modules import delete_ui  # ✅ Inject delete buttons inline


def ask_openai(history):
    system_prompt = {
        "role": "system",
        "content": (
            "You are the controller of a trading bot. "
            "When the user types a command like "
            "'start test_strategy with {\"lot_size\": 0.1}', respond ONLY in JSON:\n"
            "{\n"
            '  "action": "start",\n'
            '  "strategy": "test_strategy",\n'
            '  "config": {"lot_size": 0.1}\n'
            "}\n\n"
            "If it's not a bot command, answer naturally."
        )
    }

    try:
        log("🤖 Sending last 5 messages to OpenAI...", actor="SYSTEM")
        for idx, msg in enumerate(history[-5:]):
            if isinstance(msg, dict):
                log(f"   → Msg[{idx}] {msg.get('role', '?')}: {repr(msg.get('content', ''))[:60]}", actor="SYSTEM")
            else:
                log(f"   ⚠️ Msg[{idx}] Malformed message: {repr(msg)}", actor="SYSTEM")

        resp = openai.chat.completions.create(
            model="gpt-4o",
            messages=[system_prompt] + history[-5:]
        )
        txt = resp.choices[0].message.content.strip()
        log(f"📥 OpenAI reply content: {repr(txt)}", actor="SYSTEM")

        return txt
    except Exception as e:
        log(f"❌ Error during ask_openai: {e}", actor="SYSTEM")
        return f"⚠️ OpenAI error: {e}"


def handle_user_input(prompt, session_name):
    log(f"🧾 User input received: {repr(prompt)}", actor="USER")

    if "messages" not in st.session_state:
        log("⚠️ 'messages' not found in session_state; initializing empty list", actor="SYSTEM")
        st.session_state.messages = []

    log(f"📊 Current message count before user append: {len(st.session_state.messages)}", actor="SYSTEM")

    try:
        st.session_state.messages.append({"role": "user", "content": prompt})
        log(f"📝 Appended user message. Total messages now: {len(st.session_state.messages)}", actor="SYSTEM")
    except Exception as e:
        log(f"❌ Exception appending user message: {e}", actor="SYSTEM")

    try:
        reply = ask_openai(st.session_state.messages)
        log("🧪 Obtained reply from OpenAI", actor="SYSTEM")
    except Exception as e:
        log(f"❌ Exception during OpenAI call: {e}", actor="SYSTEM")
        reply = "⚠️ Failed to contact assistant"

    if not reply:
        log("⚠️ Reply is empty or None, replacing with placeholder", actor="SYSTEM")
        reply = "⚠️ (No reply from assistant)"

    try:
        assistant_message = {"role": "assistant", "content": str(reply)}
        st.session_state.messages.append(assistant_message)
        log("📝 Appended assistant message:", actor="SYSTEM")
        log(f"     {assistant_message}", actor="SYSTEM")

        with open("debug_post_append.json", "w", encoding="utf-8") as f:
            json.dump(st.session_state.messages, f, indent=2, ensure_ascii=False)
        log("📦 Wrote debug_post_append.json after assistant append", actor="SYSTEM")
    except Exception as e:
        log(f"❌ Exception while appending assistant reply: {e}", actor="SYSTEM")
        st.session_state.messages.append({"role": "assistant", "content": "⚠️ Failed to append assistant reply due to error."})

    try:
        with open("debug_messages_snapshot.json", "w", encoding="utf-8") as f:
            json.dump(st.session_state.messages, f, indent=2, ensure_ascii=False)
        log("📦 Saved JSON snapshot to debug_messages_snapshot.json", actor="SYSTEM")
    except Exception as e:
        log(f"⚠️ Failed to save debug snapshot: {e}", actor="SYSTEM")

    # ✅ NEW: Save session messages to disk
    try:
        save_session(session_name, st.session_state.messages)
        log(f"📁 Saved session '{session_name}' to memory.json", actor="SYSTEM")
    except Exception as e:
        log(f"❌ Error saving session: {e}", actor="SYSTEM")

    try:
        log("✅ All processing complete. Calling st.rerun()", actor="SYSTEM")
        st.success("✅ Assistant reply ready. Updating UI...")
        st.rerun()
    except Exception as e:
        log(f"❌ Exception calling st.rerun(): {e}", actor="SYSTEM")


# ✅ REPLACED render() WITH SESSION-AWARE VERSION
def render(session_name):
    log(f"🔁 Streamlit rerun @ {datetime.now()}", actor="SYSTEM")

    if st.session_state.get("last_loaded_session") != session_name:
        st.session_state.messages = load_session(session_name)
        st.session_state.last_loaded_session = session_name
        log(f"📥 Loaded messages for new session: {session_name}", actor="SYSTEM")

    if "messages" not in st.session_state:
        st.session_state.messages = []
        log("📂 Initialized empty message history", actor="SYSTEM")
    else:
        log(f"✅ Messages in session_state: {len(st.session_state.messages)}", actor="SYSTEM")

    for i, msg in enumerate(st.session_state.messages):
        if isinstance(msg, dict) and "role" in msg and "content" in msg:
            with st.chat_message(msg["role"]):
                st.markdown(msg["content"])
                delete_ui.inject_delete_button(session_name, i)  # ✅ FIXED ARG ORDER
        else:
            log(f"⚠️ Skipping malformed message at index {i}: {repr(msg)}", actor="SYSTEM")

    prompt = st.chat_input("Type here...")
    if prompt:
        handle_user_input(prompt, session_name)
