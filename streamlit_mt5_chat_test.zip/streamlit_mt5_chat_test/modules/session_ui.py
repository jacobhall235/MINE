import streamlit as st
from modules import session_manager
from modules.error_handler import handle  # ✅ Error handler
from modules.logger import log  # ✅ Super logger

def main():
    st.sidebar.title("🧠 Your Chats")
    log("🧭 Sidebar loaded with chat session controls.", actor="SYSTEM")

    sessions = session_manager.get_sessions()

    # ➕ New Chat Button
    if st.sidebar.button("➕ New Chat"):
        new_session = session_manager.add_session()
        log(f"🆕 New chat session created: {new_session}", actor="USER")
        st.session_state.session_select = new_session  # ✅ Force radio to show new session
        st.session_state.current_session = new_session  # ✅ Ensure app picks it up
        st.rerun()

    # 📌 Session selection
    if sessions:
        selected = st.sidebar.radio("Select a chat", sessions, index=0, key="session_select")

        # ✅ Log only if selection changed
        if st.session_state.get("last_logged_session") != selected:
            log(f"📌 User selected session: {selected}", actor="USER")
            st.session_state["last_logged_session"] = selected

        return selected
    else:
        log("📭 No existing sessions to select.", actor="SYSTEM")
        return None

def render():
    try:
        return main()
    except Exception as e:
        handle(e, context="session_ui")
        return None
