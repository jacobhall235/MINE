import MetaTrader5 as mt5
import pandas as pd
from modules.error_handler import handle
from modules.logger import log

# ✅ Initialization
def initialize():
    try:
        success = mt5.initialize()
        if success:
            log("✅ MT5 initialized successfully.", actor="SYSTEM")
        else:
            log("❌ MT5 initialization failed.", actor="SYSTEM")
        return success
    except Exception as e:
        handle(e, context="mt5_connect → initialize")
        return False

def shutdown():
    try:
        mt5.shutdown()
        log("🔌 MT5 shutdown successfully.", actor="SYSTEM")
    except Exception as e:
        handle(e, context="mt5_connect → shutdown")

def is_connected():
    try:
        connected = mt5.initialize() and mt5.account_info() is not None
        if connected:
            log("🟢 MT5 connection verified.", actor="SYSTEM")
        else:
            log("🔴 MT5 not connected or account info unavailable.", actor="SYSTEM")
        return connected
    except Exception as e:
        handle(e, context="mt5_connect → is_connected")
        return False

# ✅ Get historical candles (robust timeframe handling)
def get_historical_data(symbol, timeframe, lookback=200):
    try:
        # 🎯 Normalize timeframe to MT5 enum
        if isinstance(timeframe, str):
            tf_variants = [
                timeframe,
                f"TIMEFRAME_{timeframe.upper()}",
                f"timeframe_{timeframe.lower()}",
            ]
            timeframe_enum = None
            for variant in tf_variants:
                if hasattr(mt5, variant):
                    timeframe_enum = getattr(mt5, variant)
                    break
            if timeframe_enum is None:
                log(f"❌ Invalid timeframe: {timeframe}", actor="SYSTEM")
                return None
        else:
            timeframe_enum = timeframe

        rates = mt5.copy_rates_from_pos(symbol, timeframe_enum, 0, lookback)
        if rates is None or len(rates) == 0:
            log(f"⚠️ No rates returned for {symbol} {timeframe}", actor="SYSTEM")
            return None

        df = pd.DataFrame(rates)
        df['time'] = pd.to_datetime(df['time'], unit='s')
        return df
    except Exception as e:
        handle(e, context="mt5_connect → get_historical_data")
        return None

# ✅ Place a market order with SL/TP (AI-defined or fallback)
def place_order(symbol, signal, config):
    try:
        lot = config.get("lot", 0.1)
        point = mt5.symbol_info(symbol).point
        price = mt5.symbol_info_tick(symbol).ask if signal == "buy" else mt5.symbol_info_tick(symbol).bid
        deviation = 10
        order_type = mt5.ORDER_TYPE_BUY if signal == "buy" else mt5.ORDER_TYPE_SELL

        # Strategy-defined SL/TP support
        sl_price = config.get("sl_price")
        tp_price = config.get("tp_price")

        # Fallback: point-based SL/TP
        if sl_price is None:
            sl_points = config.get("sl_points", 200)
            sl_price = price - sl_points * point if signal == "buy" else price + sl_points * point

        if tp_price is None:
            tp_points = config.get("tp_points", 200)
            tp_price = price + tp_points * point if signal == "buy" else price - tp_points * point

        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": symbol,
            "volume": lot,
            "type": order_type,
            "price": price,
            "sl": sl_price,
            "tp": tp_price,
            "deviation": deviation,
            "magic": 234000,
            "comment": "Autobot",
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }

        result = mt5.order_send(request)
        if result.retcode != mt5.TRADE_RETCODE_DONE:
            log(f"❌ Order send failed: {result.retcode}", context="MT5")
            return False

        log(f"📈 Order placed: {signal} {symbol} @ {price}\nSL: {sl_price:.5f} | TP: {tp_price:.5f}", context="MT5")
        return True
    except Exception as e:
        handle(e, context="mt5_connect → place_order")
        return False

# ✅ Get current open position for symbol
def get_open_position(symbol):
    try:
        positions = mt5.positions_get(symbol=symbol)
        if positions:
            return positions[0]  # Assumes one position per symbol
        return None
    except Exception as e:
        handle(e, context="mt5_connect → get_open_position")
        return None

# ✅ Check if SL/TP condition is hit
def should_close_position(position, config):
    try:
        symbol = position.symbol
        price = mt5.symbol_info_tick(symbol).bid if position.type == mt5.ORDER_TYPE_SELL else mt5.symbol_info_tick(symbol).ask
        profit = position.profit
        max_loss = config.get("max_loss", -100)
        max_profit = config.get("max_profit", 200)
        if profit <= max_loss or profit >= max_profit:
            return True
        return False
    except Exception as e:
        handle(e, context="mt5_connect → should_close_position")
        return False

# ✅ Close open position
def close_position(position):
    try:
        symbol = position.symbol
        volume = position.volume
        order_type = mt5.ORDER_TYPE_SELL if position.type == mt5.ORDER_TYPE_BUY else mt5.ORDER_TYPE_BUY
        price = mt5.symbol_info_tick(symbol).bid if order_type == mt5.ORDER_TYPE_SELL else mt5.symbol_info_tick(symbol).ask

        close_request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": symbol,
            "volume": volume,
            "type": order_type,
            "position": position.ticket,
            "price": price,
            "deviation": 10,
            "magic": 234000,
            "comment": "Auto-close",
            "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": mt5.ORDER_FILLING_IOC,
        }

        result = mt5.order_send(close_request)
        if result.retcode == mt5.TRADE_RETCODE_DONE:
            log(f"✅ Closed position on {symbol}", context="MT5")
            return True
        else:
            log(f"❌ Failed to close position: {result.retcode}", context="MT5")
            return False
    except Exception as e:
        handle(e, context="mt5_connect → close_position")
        return False
