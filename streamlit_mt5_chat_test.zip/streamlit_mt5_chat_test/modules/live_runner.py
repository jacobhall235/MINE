# modules/live_runner.py

from modules.mt5_connect import mt5
from modules.logger import log

_live_state = {
    "symbol": None,
    "last_pnl": None,
}

def get_latest_cached_pnl():
    """Fetch latest floating PnL from MT5 positions."""
    positions = mt5.positions_get()
    if positions is None:
        log("❌ Failed to fetch positions from MT5", actor="SYSTEM")
        return None

    total_pnl = sum(pos.profit for pos in positions)
    _live_state["last_pnl"] = total_pnl
    return total_pnl

def get_current_symbol():
    """Return current traded symbol based on open positions."""
    positions = mt5.positions_get()
    if positions and len(positions) > 0:
        symbol = positions[0].symbol
        _live_state["symbol"] = symbol
        return symbol
    return "-"
