import streamlit as st
import modules.session_manager as session_manager
from modules.error_handler import handle
from modules.logger import log

def clear_message_flags():
    for key in list(st.session_state.keys()):
        if key.startswith("confirm_delete_msg_"):
            st.session_state.pop(key, None)
    log("🧹 Cleared message confirmation flags.", actor="SYSTEM")

def clear_session_flags():
    for key in list(st.session_state.keys()):
        if key.startswith("confirm_del_session_"):
            st.session_state.pop(key, None)
    log("🧹 Cleared session confirmation flags.", actor="SYSTEM")

# ✅ Inject delete button only, no rendering messages here
def inject_delete_button(session_name, i):
    index = int(i)  # 🩺 Ensure index is always int
    msg = st.session_state.messages[index]
    confirm_key = f"confirm_delete_msg_{index}"
    del_button_key = f"delbtn_msg_{index}"

    if st.session_state.get(confirm_key):
        c1, c2 = st.columns(2)
        with c1:
            if st.button("✅ Confirm", key=f"confirm_msg_{index}"):
                del st.session_state.messages[index]
                session_manager.save_session(session_name, st.session_state.messages)
                clear_message_flags()
                log(f"🗑 Message {index} deleted from session '{session_name}'", actor="SYSTEM")
                st.rerun()
        with c2:
            if st.button("❌ Cancel", key=f"cancel_msg_{index}"):
                st.session_state.pop(confirm_key, None)
                log(f"❌ Canceled delete for message {index}", actor="USER")
                st.rerun()
    else:
        if st.button("🗑", key=del_button_key):
            clear_message_flags()
            clear_session_flags()
            st.session_state[confirm_key] = True
            log(f"🗑 Delete clicked for message {index}", actor="USER")
            st.rerun()

def render_session_deletes():
    sessions = session_manager.get_sessions()
    st.sidebar.subheader("🧾 Sessions")

    for s in sessions:
        row = st.sidebar.columns([0.8, 0.2])
        with row[0]:
            if st.button(s, key=f"load_session_{s}"):
                st.session_state["selected_session"] = s
                st.session_state["current_session"] = s
                clear_message_flags()
                clear_session_flags()
                log(f"📂 Switched to session: {s}", actor="USER")
                st.rerun()

        with row[1]:
            confirm_key = f"confirm_del_session_{s}"

            if st.session_state.get(confirm_key):
                confirm_row = st.sidebar.columns(2)
                with confirm_row[0]:
                    if st.button("✅", key=f"confirm_session_{s}"):
                        session_manager.delete_session(s)
                        clear_session_flags()
                        st.session_state.pop("selected_session", None)
                        st.session_state.pop("current_session", None)
                        st.session_state.pop("messages", None)

                        log(f"🗑 Session '{s}' deleted.", actor="USER")

                        if not session_manager.get_sessions():
                            log("🧹 All sessions deleted. Resetting state.", actor="SYSTEM")

                        st.rerun()

                with confirm_row[1]:
                    if st.button("❌", key=f"cancel_session_{s}"):
                        st.session_state.pop(confirm_key, None)
                        log(f"❌ Cancelled session delete: {s}", actor="USER")
                        st.rerun()
            else:
                if st.button("🗑", key=f"del_session_{s}"):
                    clear_session_flags()
                    clear_message_flags()
                    st.session_state[confirm_key] = True
                    log(f"🗑 Delete requested for session: {s}", actor="USER")
                    st.rerun()

def render():
    try:
        render_session_deletes()
        log("🧩 delete_ui.render() executed.", actor="SYSTEM")
    except Exception as e:
        handle(e, context="delete_ui")
