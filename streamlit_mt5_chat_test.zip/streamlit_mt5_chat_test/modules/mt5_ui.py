import streamlit as st
from modules.mt5_connect import initialize  # ✅ Use your real initializer
from modules.error_handler import handle
from modules.logger import log

def main():
    st.sidebar.title("MT5 Control")

    # ✅ Ensure status key exists in session state
    if "mt5_status" not in st.session_state:
        st.session_state.mt5_status = None

    # 🔘 Connect button logic
    if st.sidebar.button("Connect to MT5"):
        log("🧑 User clicked 'Connect to MT5' button.", actor="USER")

        if initialize():
            st.session_state.mt5_status = "connected"
            log("✅ MT5 connected successfully.", actor="SYSTEM")
        else:
            st.session_state.mt5_status = "failed"
            log("❌ MT5 connection failed.", actor="SYSTEM")

    # ✅ Show persistent status message
    if st.session_state.mt5_status == "connected":
        st.sidebar.success("✅ MT5 Connected Successfully!")
    elif st.session_state.mt5_status == "failed":
        st.sidebar.error("❌ MT5 Connection Failed.")

def render():
    try:
        main()
    except Exception as e:
        handle(e, context="mt5_ui")

